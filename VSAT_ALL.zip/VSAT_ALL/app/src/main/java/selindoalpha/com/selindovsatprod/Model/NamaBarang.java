package selindoalpha.com.selindovsatprod.Model;

public class NamaBarang {


    String namaBarang;

    public NamaBarang(){

    }

    public NamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String NamaBr){
        this.namaBarang =NamaBr;
    }

}
