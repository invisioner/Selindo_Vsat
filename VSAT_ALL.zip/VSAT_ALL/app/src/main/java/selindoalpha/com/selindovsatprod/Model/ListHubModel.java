package selindoalpha.com.selindovsatprod.Model;

public class ListHubModel {

    String Hub;

    public ListHubModel(String hub) {
        Hub = hub;
    }

    public String getHub() {
        return Hub;
    }

    public void setHub(String hub) {
        Hub = hub;
    }
}
